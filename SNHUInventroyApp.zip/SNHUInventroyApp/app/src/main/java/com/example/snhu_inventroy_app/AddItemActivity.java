package com.example.snhu_inventroy_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddItemActivity extends AppCompatActivity {
    // reference
    private Button buttonAdd, buttonBack;
    private EditText textName, textCount;
    private DBHelper db;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // assign reference
        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonBack = (Button) findViewById(R.id.buttonBack);
        textName = (EditText) findViewById(R.id.textName);
        textCount = (EditText) findViewById(R.id.textCount);

        // setup database
        db = new DBHelper(this);

        // get email from user
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("email");
            this.setEmail(value);
        }

        // setup back button
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPage = new Intent(AddItemActivity.this, MainActivity.class);
                nextPage.putExtra("email", email);
                startActivity(nextPage);
            }
        });

        // setup add button
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.createItem(textName.getText().toString(), textCount.getText().toString(), email);
                Intent nextPage = new Intent(AddItemActivity.this, MainActivity.class);
                nextPage.putExtra("email", email);
                startActivity(nextPage);
            }
        });

    }

    // email setter
    public void setEmail(String email) {
        this.email = email;
    }

    // email getter
    public String getEmail() {
        return this.email;
    }
}