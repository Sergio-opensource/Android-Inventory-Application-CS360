package com.example.snhu_inventroy_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    // user login table
    private static final String DATABASE_NAME = "USER_RECORDS";
    private static final String TABLE_NAME = "USER_DATA";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "EMAIL";
    private static final String COL_3 = "PASSWORD";

    // items table
    private static final String _TABLE_NAME = "ITEM_DATA";
    private static final String _COL_1 = "ID";
    private static final String _COL_2 = "NAME";
    private static final String _COL_3 = "COUNT";
    private static final String _COL_4 = "EMAIL";

    private DBHelper db;

    // constructor
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS "+TABLE_NAME+"(ID INTEGER PRIMARY KEY AUTOINCREMENT, EMAIL TEXT , PASSWORD TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS "+_TABLE_NAME+"(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT , COUNT TEXT, EMAIL TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS "+TABLE_NAME);
        db.execSQL(" DROP TABLE IF EXISTS "+_TABLE_NAME);
        onCreate(db);
    }

    // register user
    public boolean registerUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2, email.trim());
        values.put(COL_3, password.trim());

        long result = db.insert(TABLE_NAME, null, values);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // check user
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = { COL_1 };
        String selection = COL_2 + "=?" + " and " + COL_3 + "=?";
        String[] selectionArgs = { username.trim(), password.trim() };
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();

        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    // create item
    public boolean createItem(String name, String count, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(_COL_2, name.trim());
        values.put(_COL_3, count.trim());
        values.put(_COL_4, email.trim());

        long result = db.insert(_TABLE_NAME, null, values);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // remove item
    public boolean removeItem(String id) {
        SQLiteDatabase db = this.getWritableDatabase();

        long result = db.delete(_TABLE_NAME,_COL_1+"=?", new String[] {id});

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // update item
    public boolean updateItem(String count, String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(_COL_3, count.trim());

        long result = db.update(_TABLE_NAME, values, _COL_1+"=?", new String[] {id}
        );

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    // read item
    public Cursor readItem(String name, String count, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = { _COL_1 };
        String selection = _COL_2 + "=?" + " and " + _COL_3 + "=?" + " and " + _COL_4 + "=?";
        String[] selectionArgs = { name.trim(), count.trim(), email.trim() };
        Cursor cursor = db.query(_TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        return cursor;
    }

    // get all items
    public String getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor allRows = db.rawQuery("select * from "+_TABLE_NAME,null);
        String tableString = String.format("Table %s:\n", _TABLE_NAME);
        if (allRows.moveToFirst() ){
            String[] columnNames = allRows.getColumnNames();
            do {
                for (String name: columnNames) {
                    tableString += String.format("%s: %s\n", name, allRows.getString((int) allRows.getColumnIndex(name)));
                }
                tableString += "\n";

            } while (allRows.moveToNext());
        }

        return tableString;
    }
}



