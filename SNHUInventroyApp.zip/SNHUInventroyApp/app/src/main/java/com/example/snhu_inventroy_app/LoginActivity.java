package com.example.snhu_inventroy_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    //reference variables
    private EditText textEmail, textPassword;
    private Button buttonLogin, buttonRegister;
    private DBHelper db;

    private AlertDialog.Builder notification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        // setup notification
        setupDialogBuilder();

        // assign reference variables
        setupReferenceVariables();

        // setup button onClick
        setupButtonLogin();
        setupButtonRegister();

    }

    // clear text fields
    private void clearText() {
        this.textEmail.setText("");
        this.textPassword.setText("");
    }

    // setup the dialog box
    private void setupDialogBuilder() {
        // setup notification
        notification = new AlertDialog.Builder(this).setTitle("dialog").setMessage("it works").setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
    }

    // setup reference variables
    private void setupReferenceVariables() {
        // assign reference variables
        textEmail = (EditText) findViewById(R.id.textEmail);
        textPassword = (EditText) findViewById(R.id.textPassword);
        buttonLogin = (Button) findViewById(R.id.buttonLogin);
        buttonRegister = (Button) findViewById(R.id.buttonRegister);
        db = new DBHelper(this);
    }

    //setup login button
    private void setupButtonLogin() {
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (db.checkUser(textEmail.getText().toString(), textPassword.getText().toString())) {
                    Intent nextPage = new Intent(LoginActivity.this, MainActivity.class);
                    nextPage.putExtra("email", textEmail.getText().toString());
                    startActivity(nextPage);
                } else {
                    notification.setTitle("ALERT").setMessage("Please register an account!!!").show();
                }
            }
        });
    }

    //setup register button
    private void setupButtonRegister() {
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (db.checkUser(textEmail.getText().toString(), textPassword.getText().toString())) {
                    notification.setTitle("ALERT").setMessage("You account already exist").show();
                } else {
                    // register user
                    db.registerUser(textEmail.getText().toString(), textPassword.getText().toString());
                    clearText();
                }
            }
        });
    }
}