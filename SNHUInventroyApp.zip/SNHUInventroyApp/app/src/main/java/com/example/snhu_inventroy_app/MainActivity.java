package com.example.snhu_inventroy_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // variables
    private String email;
    private Button buttonAddItem;
    private TableLayout tableItems;
    private DBHelper db;
    SharedPreferences permissionStatus;
    private boolean sentToSettings = false;
    private static final int SMS_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set references
        buttonAddItem = (Button) findViewById(R.id.buttonAddItem);
        tableItems = (TableLayout) findViewById(R.id.tableItems);
        db = new DBHelper(this);

        // set up permission
        permissionStatus = getSharedPreferences("permissionStatus", MODE_PRIVATE);
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.SEND_SMS)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Need SMS Permission");
                builder.setMessage("This app needs SMS permission to send Messages.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[] {
                                        Manifest.permission.SEND_SMS
                                }, SMS_PERMISSION_CONSTANT);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else if (permissionStatus.getBoolean(Manifest.permission.SEND_SMS, false)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Need SMS Permission");
                builder.setMessage("This app needs SMS permission to send Messages.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        sentToSettings = true;
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                        intent.setData(uri);
                        startActivityForResult(intent, REQUEST_PERMISSION_SETTING);
                        Toast.makeText(getBaseContext(),
                                "Go to Permissions to Grant SMS permissions", Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else {
                ActivityCompat.requestPermissions(MainActivity.this, new String[] {
                        Manifest.permission.SEND_SMS
                }, SMS_PERMISSION_CONSTANT);
            }

            SharedPreferences.Editor editor = permissionStatus.edit();
            editor.putBoolean(Manifest.permission.SEND_SMS, true);
            editor.commit();
        }

        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPage = new Intent(MainActivity.this, AddItemActivity.class);
                nextPage.putExtra("email", email);
                startActivity(nextPage);
            }
        });

        // get email from user
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("email");
            this.setEmail(value);
        }

        this.populateList();

    }

    // email setter
    public void setEmail(String email) {
        this.email = email;
    }

    // email getter
    public String getEmail() {
        return this.email;
    }

    // populate the list with data from the db
    private void populateList() {
        String data = this.db.getAllItems();
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<String> counts = new ArrayList<String>();
        ArrayList<String> ids = new ArrayList<String>();

        // split string by new line
        String lines[] = data.split(System.lineSeparator());

        // loop data
        for (String line: lines) {
            String tmp;
            // find name
            if (line.contains("NAME")) {
                tmp = line.substring(line.indexOf(':')+1);
                names.add(tmp);
            } else if (line.contains("COUNT")) { // find count
                tmp = line.substring(line.indexOf(':') + 1);
                counts.add(tmp);
            } else if (line.contains("ID")) { // find count
                tmp = line.substring(line.indexOf(':') + 1);
                ids.add(tmp);
            }
        }

        // clear layout
        tableItems.removeAllViews();

        // add row to table
        for (int i=0; i<names.size(); i++) {
            // instance row
            TableRow row = new TableRow(this);
            row.setPadding(0,40,0,40);
            TextView itemName = new TextView(this);
            itemName.setMaxWidth(500);
            TextView itemCount = new TextView(this);
            itemCount.setPadding(20, 0, 20, 0);
            Button buttonIncrease = new Button(this);
            buttonIncrease.setText("+");
            buttonIncrease.setTextSize(18);
            buttonIncrease.setLayoutParams (new TableRow.LayoutParams(200, 150));
            Button buttonDecrease = new Button(this);
            buttonDecrease.setText("-");
            buttonDecrease.setTextSize(18);
            buttonDecrease.setLayoutParams (new TableRow.LayoutParams(200, 150));
            Button buttonDelete = new Button(this);
            buttonDelete.setText("X");
            buttonDelete.setTextSize(18);
            buttonDelete.setLayoutParams (new TableRow.LayoutParams(200, 150));


            // set data
            itemName.setText(names.get(i));
            itemName.setTextSize(26);
            itemCount.setText(counts.get(i));
            itemCount.setTextSize(26);

            final String name = names.get(i).trim();
            final String count = counts.get(i).trim();
            final String id = ids.get(i).trim();
            final String email = getEmail().trim();

            // assign buttons w/ appropriate function
            buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    db.removeItem(id);
                    populateList();
                }
            });

            buttonIncrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int _count = Integer.parseInt(count);
                    _count += 1;
                    String _countString = String.valueOf(_count);
                    db.updateItem(_countString, id);
                    populateList();
                }
            });

            buttonDecrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int _count = Integer.parseInt(count);
                    _count -= 1;
                    String _countString = String.valueOf(_count);
                    db.updateItem(_countString, id);
                    populateList();
                }
            });


            // add to the row
            row.addView(itemName);
            row.addView(itemCount);
            row.addView(buttonIncrease);
            row.addView(buttonDecrease);
            row.addView(buttonDelete);

            // add to the table layout
            tableItems.addView(row);


        }



    }

    public void SendMessage(String strMobileNo, String strMessage) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(strMobileNo, null, strMessage, null, null);
            Toast.makeText(getApplicationContext(), "Your Message Sent",
                    Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), ex.getMessage().toString(),
                    Toast.LENGTH_LONG).show();
        }
    }
}